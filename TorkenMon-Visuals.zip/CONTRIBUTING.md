# Contributing

## Textures

- `@mnesikos` on Discord with the textures for the Horse, Villager and Legacy Smithing containers and other small gui elements.
- @TorchTheDragon (`@torchthedragon` on Discord) with the Bundle and Gamemode Switcher GUI elements.
- XandoR (`@xandor4223` on Discord) with fixes for gui sprites.